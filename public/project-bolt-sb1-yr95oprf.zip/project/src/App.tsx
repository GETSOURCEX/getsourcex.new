import { useState, useEffect } from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import ProofBar from './components/ProofBar';
import Problem from './components/Problem';
import Solution from './components/Solution';
import ValueStack from './components/ValueStack';
import About from './components/About';
import FAQ from './components/FAQ';
import FinalCTA from './components/FinalCTA';
import Footer from './components/Footer';
import ThankYou from './pages/ThankYou';

function App() {
  const [currentPage, setCurrentPage] = useState('home');

  useEffect(() => {
    const path = window.location.pathname;
    if (path === '/thank-you') {
      setCurrentPage('thank-you');
    } else {
      setCurrentPage('home');
    }

    const handlePopState = () => {
      const path = window.location.pathname;
      if (path === '/thank-you') {
        setCurrentPage('thank-you');
      } else {
        setCurrentPage('home');
      }
    };

    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  if (currentPage === 'thank-you') {
    return <ThankYou />;
  }

  return (
    <div className="min-h-screen bg-black">
      <Header />
      <Hero />
      <ProofBar />
      <Problem />
      <Solution />
      <ValueStack />
      {/* Real Results section temporarily removed - no client results available yet */}
      {/* To restore: import and add ClientShowcase component here */}
      <About />
      <FAQ />
      <FinalCTA />
      <Footer />
    </div>
  );
}

export default App;
