
export default function About() {
  return (
    <section id="about" className="py-20 bg-black">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">
            Born Inside Clinics.
            <br />
            <span className="bg-gradient-to-r from-blue-400 to-cyan-300 bg-clip-text text-transparent">
              Built for Results.
            </span>
          </h2>
        </div>

        <div className="grid md:grid-cols-2 gap-8 mb-12">
          <div className="bg-gradient-to-br from-slate-800 to-slate-900 border border-blue-400/20 rounded-2xl p-8">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-gradient-to-r from-blue-500 to-blue-600 mb-6">
              <span className="text-white font-bold text-2xl">M</span>
            </div>
            <h3 className="text-2xl font-bold text-white mb-4">Our Mission</h3>
            <p className="text-gray-300 leading-relaxed">
              We're not theorists, we've lived the same front-desk chaos. Source X was born inside real clinics facing missed calls, no-shows, and lost patients.
            </p>
            <p className="text-gray-300 leading-relaxed mt-4">
              We built the $10K Clinic Fix to solve those exact problems using smart automation that feels human.
            </p>
          </div>

          <div className="bg-gradient-to-br from-slate-800 to-slate-900 border border-cyan-400/20 rounded-2xl p-8">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-gradient-to-r from-cyan-500 to-cyan-600 mb-6">
              <span className="text-white font-bold text-2xl">G</span>
            </div>
            <h3 className="text-2xl font-bold text-white mb-4">Our Guarantee</h3>
            <div className="bg-gradient-to-r from-green-500/10 to-cyan-500/10 border border-green-400/30 rounded-xl p-6">
              <div className="text-3xl font-bold text-white mb-2">25 Show-Up Guarantee</div>
              <p className="text-gray-300 leading-relaxed">
                Every installation is backed by our 25 Show-Up Guarantee, if we don't deliver 25 booked consults in 30 days, your setup is free.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
