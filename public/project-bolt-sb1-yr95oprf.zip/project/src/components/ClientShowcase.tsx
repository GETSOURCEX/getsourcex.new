export default function ClientShowcase() {
  // Create an array of client logos with professional fictional brand names
  const clients = [
    { name: 'VitalCare Clinics', text: 'VitalCare' },
    { name: 'MedPro Solutions', text: 'MedPro' },
    { name: 'HealthFirst Partners', text: 'HealthFirst' },
    { name: 'WellnessHub Group', text: 'WellnessHub' },
    { name: 'CarePoint Medical', text: 'CarePoint' },
    { name: 'PrimeCare Health', text: 'PrimeCare' },
    { name: 'Elite Wellness', text: 'Elite Wellness' },
    { name: 'MediCore Systems', text: 'MediCore' },
  ];

  // Duplicate the array for seamless infinite scroll
  const duplicatedClients = [...clients, ...clients];

  return (
    <section id="results" className="py-20 bg-black overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">
            Trusted by Industry Leaders
          </h2>
          <p className="text-xl text-gray-400">
            Partnering with clinics across the GTA to transform their revenue operations
          </p>
        </div>

        {/* Logo Carousel Container */}
        <div className="relative">
          {/* Gradient overlays for fade effect */}
          <div className="absolute left-0 top-0 bottom-0 w-32 bg-gradient-to-r from-black to-transparent z-10"></div>
          <div className="absolute right-0 top-0 bottom-0 w-32 bg-gradient-to-l from-black to-transparent z-10"></div>

          {/* Scrolling container */}
          <div className="logo-carousel-wrapper">
            <div className="logo-carousel">
              {duplicatedClients.map((client, index) => (
                <div
                  key={index}
                  className="logo-item group"
                  aria-label={client.name}
                >
                  <div className="logo-card">
                    <div className="logo-content">
                      <div className="logo-icon">
                        {/* Abstract logo icon */}
                        <svg
                          viewBox="0 0 100 100"
                          fill="none"
                          xmlns="http://www.w3.org/2000/svg"
                          className="w-12 h-12"
                        >
                          {/* Different shapes for variety */}
                          {index % 8 === 0 && (
                            <>
                              <circle cx="50" cy="50" r="20" className="fill-blue-400" />
                              <path
                                d="M50 20 L65 45 L35 45 Z"
                                className="fill-cyan-400"
                              />
                            </>
                          )}
                          {index % 8 === 1 && (
                            <>
                              <rect
                                x="30"
                                y="30"
                                width="40"
                                height="40"
                                rx="8"
                                className="fill-blue-400"
                              />
                              <circle cx="50" cy="50" r="12" className="fill-cyan-400" />
                            </>
                          )}
                          {index % 8 === 2 && (
                            <>
                              <path
                                d="M50 25 L70 50 L50 75 L30 50 Z"
                                className="fill-blue-400"
                              />
                              <circle cx="50" cy="50" r="10" className="fill-cyan-400" />
                            </>
                          )}
                          {index % 8 === 3 && (
                            <>
                              <path
                                d="M30 50 Q30 30 50 30 Q70 30 70 50 Q70 70 50 70 Q30 70 30 50"
                                className="fill-blue-400"
                              />
                            </>
                          )}
                          {index % 8 === 4 && (
                            <>
                              <polygon
                                points="50,25 70,40 70,60 50,75 30,60 30,40"
                                className="fill-blue-400"
                              />
                            </>
                          )}
                          {index % 8 === 5 && (
                            <>
                              <circle cx="35" cy="50" r="15" className="fill-blue-400" />
                              <circle cx="65" cy="50" r="15" className="fill-cyan-400" />
                            </>
                          )}
                          {index % 8 === 6 && (
                            <>
                              <path
                                d="M50 30 L65 45 L60 65 L40 65 L35 45 Z"
                                className="fill-blue-400"
                              />
                            </>
                          )}
                          {index % 8 === 7 && (
                            <>
                              <rect
                                x="35"
                                y="35"
                                width="30"
                                height="30"
                                className="fill-blue-400"
                                transform="rotate(45 50 50)"
                              />
                            </>
                          )}
                        </svg>
                      </div>
                      <span className="logo-text">{client.text}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Stats below carousel */}
        <div className="mt-16 grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
          <div className="p-6">
            <div className="text-4xl font-bold text-blue-400 mb-2">50+</div>
            <div className="text-gray-400 uppercase tracking-wider text-sm">
              Partner Clinics
            </div>
          </div>
          <div className="p-6">
            <div className="text-4xl font-bold text-cyan-400 mb-2">$2M+</div>
            <div className="text-gray-400 uppercase tracking-wider text-sm">
              Revenue Recovered
            </div>
          </div>
          <div className="p-6">
            <div className="text-4xl font-bold text-blue-400 mb-2">98%</div>
            <div className="text-gray-400 uppercase tracking-wider text-sm">
              Client Satisfaction
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
