import { useState } from 'react';

export default function FAQ() {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const faqs = [
    {
      question: "What's the catch?",
      answer: "None. The first 5 clinics per month get the Fix free as part of our GTA pilot.",
    },
    {
      question: 'How long does setup take?',
      answer: '48 hours from your audit to installation.',
    },
    {
      question: 'Does this replace my staff?',
      answer: 'No, it helps your staff focus on patients while AI handles the repetitive tasks.',
    },
    {
      question: "What if it doesn't work?",
      answer: "You'll see your ROI numbers before installation, and our 25 Show-Up Guarantee ensures zero risk.",
    },
  ];

  return (
    <section className="py-20 bg-black">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">
            Frequently Asked Questions
          </h2>
          <p className="text-xl text-gray-400">
            Everything you need to know about The $10K Clinic Fix
          </p>
        </div>

        <div className="space-y-4 mb-12">
          {faqs.map((faq, index) => (
            <div
              key={index}
              className="bg-gradient-to-br from-slate-800 to-slate-900 border border-blue-400/20 rounded-xl overflow-hidden transition-all duration-300 hover:border-blue-400/50"
            >
              <button
                onClick={() => setOpenIndex(openIndex === index ? null : index)}
                className="w-full px-6 py-5 flex items-center justify-between text-left group"
              >
                <span className="text-lg font-semibold text-white pr-8">{faq.question}</span>
                <div
                  className={`text-2xl text-blue-400 flex-shrink-0 transition-transform duration-300 font-bold ${
                    openIndex === index ? 'transform rotate-180' : ''
                  }`}
                >
                  ⌄
                </div>
              </button>
              <div
                className={`overflow-hidden transition-all duration-300 ${
                  openIndex === index ? 'max-h-96' : 'max-h-0'
                }`}
              >
                <div className="px-6 pb-5 text-gray-400 leading-relaxed">{faq.answer}</div>
              </div>
            </div>
          ))}
        </div>

        <div className="bg-gradient-to-r from-blue-500/10 to-cyan-500/10 border border-blue-400/30 rounded-xl p-6 text-center">
          <p className="text-gray-300 text-lg">
            For more questions, contact us at{' '}
            <a href="mailto:support@getsourcex.com" className="text-blue-400 hover:text-blue-300 font-semibold">
              support@getsourcex.com
            </a>
          </p>
        </div>
      </div>
    </section>
  );
}
