
export default function FinalCTA() {
  return (
    <section id="contact" className="py-20 bg-black relative overflow-hidden">
      <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiMyMTk2RjMiIGZpbGwtb3BhY2l0eT0iMC4wNSI+PHBhdGggZD0iTTM2IDE2YzAtMy4zMTQgMi42ODYtNiA2LTZzNi0yLjY4NiA2LTZWMGgtNnYyYy0yLjIxIDAtNCAxLjc5LTQgNHMxLjc5IDQgNCA0aDZ2Nmg2di02aDJ2LTJoLTZ2LTJoNnYtMmgtNnYtMmg2di0yYzAtMy4zMTQtMi42ODYtNi02LTZzLTYtMi42ODYtNi02VjBoNnYyYzIuMjEgMCA0IDEuNzkgNCA0cy0xLjc5IDQtNCA0aC02djZoLTZ2Nmg2djJoLTZ2Mmg2djJoLTZ2MmMwIDMuMzE0IDIuNjg2IDYgNiA2cy02IDIuNjg2LTYgNnYyaC02di0yYy0yLjIxIDAtNC0xLjc5LTQtNHMxLjc5LTQgNC00aDZ2LTZoNnYtNmgtNnYtMmg2di0ySDM2eiIvPjwvZz48L2c+PC9zdmc+')] opacity-10"></div>

      <div className="relative max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <h2 className="text-4xl md:text-6xl font-bold text-white mb-6">
          Ready to Recover $10K in 30 Days?
        </h2>
        <p className="text-xl text-gray-300 mb-8 max-w-3xl mx-auto leading-relaxed">
          Get your personalized plan, your AI ROI Snapshot, and see the real numbers before you decide.
        </p>

        <div className="flex flex-wrap justify-center gap-6 mb-12">
          <div className="bg-slate-800/50 border border-blue-400/30 rounded-lg px-8 py-5">
            <div className="text-blue-400 font-bold text-lg">$10K+ Recovery</div>
          </div>
          <div className="bg-slate-800/50 border border-cyan-400/30 rounded-lg px-8 py-5">
            <div className="text-cyan-400 font-bold text-lg">48-Hour Setup</div>
          </div>
          <div className="bg-slate-800/50 border border-green-400/30 rounded-lg px-8 py-5">
            <div className="text-green-400 font-bold text-lg">25 Show-Up Guarantee</div>
          </div>
        </div>

        <button
          onClick={() => {
            const element = document.querySelector('form');
            if (element) {
              element.scrollIntoView({ behavior: 'smooth', block: 'center' });
            }
          }}
          className="bg-gradient-to-r from-blue-500 to-cyan-500 hover:from-blue-600 hover:to-cyan-600 text-white font-bold py-5 px-10 rounded-lg transition-all duration-300 transform hover:scale-105 shadow-2xl hover:shadow-blue-500/50 text-xl"
        >
          Claim My Free $10K Clinic Fix
        </button>

        <p className="text-sm text-gray-500 mt-6">
          Limited to 5 GTA clinics per month
        </p>
      </div>
    </section>
  );
}
