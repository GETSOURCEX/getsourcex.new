import logo from '../assets/FINAL LOGO .png';

export default function Footer() {
  return (
    <footer className="bg-gradient-to-b from-black to-black border-t border-blue-400/20 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-2 gap-8 mb-8">
          <div>
            <div className="flex items-center space-x-3 mb-4">
              <img
                src={logo}
                alt="SOURCE X Logo"
                className="h-12 w-auto"
              />
              <span className="text-2xl md:text-3xl font-bold text-white tracking-wide">
                SOURCE X
              </span>
            </div>
            <p className="text-gray-400 max-w-md">
              AI Automation for Modern Clinics. Helping GTA clinics recover hidden revenue through smart automation.
            </p>
          </div>

          <div className="space-y-4">
            <h3 className="text-xl font-bold text-white mb-4">Contact Us</h3>
            <div className="text-gray-400 hover:text-white transition-colors">
              <div className="text-xs text-blue-400 uppercase tracking-wider mb-1">Email</div>
              <a href="mailto:info@getsourcex.com" className="text-base">info@getsourcex.com</a>
            </div>
            <div className="text-gray-400 hover:text-white transition-colors">
              <div className="text-xs text-blue-400 uppercase tracking-wider mb-1">Phone</div>
              <a href="tel:+14375240276" className="text-base">(437) 524-0276</a>
            </div>
            <div className="text-gray-400 hover:text-white transition-colors">
              <div className="text-xs text-blue-400 uppercase tracking-wider mb-1">Website</div>
              <a href="https://getsourcex.com" target="_blank" rel="noopener noreferrer" className="text-base">
                getsourcex.com
              </a>
            </div>
          </div>
        </div>

        <div className="border-t border-slate-800 pt-8 text-center text-gray-500 text-sm">
          <p>&copy; {new Date().getFullYear()} Source X. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
