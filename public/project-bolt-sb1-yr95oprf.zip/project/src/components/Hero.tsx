import { useState, useEffect } from 'react';

export default function Hero() {
  const [counter, setCounter] = useState(0);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    mobile: '',
    clinic: '',
    consent: false,
  });

  useEffect(() => {
    const target = 10000;
    const duration = 2000;
    const steps = 60;
    const increment = target / steps;
    let current = 0;

    const timer = setInterval(() => {
      current += increment;
      if (current >= target) {
        setCounter(target);
        clearInterval(timer);
      } else {
        setCounter(Math.floor(current));
      }
    }, duration / steps);

    return () => clearInterval(timer);
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const form = e.target as HTMLFormElement;
    const submitButton = form.querySelector('button[type="submit"]') as HTMLButtonElement;

    if (submitButton) {
      submitButton.disabled = true;
      submitButton.textContent = 'Submitting...';
    }

    const formDataObj = new FormData(form);

    fetch('https://formspree.io/f/mldzbjke', {
      method: 'POST',
      body: formDataObj,
      headers: {
        Accept: 'application/json',
      },
    })
      .then((response) => {
        if (response.ok) {
          window.history.pushState({}, '', '/thank-you');
          window.dispatchEvent(new PopStateEvent('popstate'));
        } else {
          if (submitButton) {
            submitButton.disabled = false;
            submitButton.textContent = 'Claim My Free $10K Clinic Fix';
          }
          alert('There was an error submitting the form. Please try again.');
        }
      })
      .catch(() => {
        if (submitButton) {
          submitButton.disabled = false;
          submitButton.textContent = 'Claim My Free $10K Clinic Fix';
        }
        alert('There was an error submitting the form. Please try again.');
      });
  };

  return (
    <section className="relative min-h-screen pt-24 pb-16 overflow-hidden">
      <div className="absolute inset-0 bg-black pointer-events-none"></div>
      <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiMyMTk2RjMiIGZpbGwtb3BhY2l0eT0iMC4wNSI+PHBhdGggZD0iTTM2IDE2YzAtMy4zMTQgMi42ODYtNiA2LTZzNi0yLjY4NiA2LTZWMGgtNnYyYy0yLjIxIDAtNCAxLjc5LTQgNHMxLjc5IDQgNCA0aDZ2Nmg2di02aDJ2LTJoLTZ2LTJoNnYtMmgtNnYtMmg2di0yYzAtMy4zMTQtMi42ODYtNi02LTZzLTYtMi42ODYtNi02VjBoNnYyYzIuMjEgMCA0IDEuNzkgNCA0cy0xLjc5IDQtNCA0aC02djZoLTZ2Nmg2djJoLTZ2Mmg2djJoLTZ2MmMwIDMuMzE0IDIuNjg2IDYgNiA2cy02IDIuNjg2LTYgNnYyaC02di0yYy0yLjIxIDAtNC0xLjc5LTQtNHMxLjc5LTQgNC00aDZ2LTZoNnYtNmgtNnYtMmg2di0ySDM2eiIvPjwvZz48L2c+PC9zdmc+')] opacity-10 pointer-events-none"></div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="text-left space-y-6 animate-fade-in">
            <h1 className="text-5xl lg:text-6xl font-bold text-white leading-tight">
              Recover{' '}
              <span className="bg-gradient-to-r from-blue-400 to-cyan-300 bg-clip-text text-transparent">
                $10K in 30 Days
              </span>
              , Without Ads, Extra Staff, or Guesswork
            </h1>
            <p className="text-xl text-gray-300 leading-relaxed">
              Your clinic is leaking thousands every month through missed calls, no-shows, and slow follow-ups.
            </p>
            <p className="text-lg text-gray-400">
              The $10K Clinic Fix identifies those leaks and helps you recover the revenue, in days, not months.
            </p>

            <div className="flex items-center space-x-4 pt-4">
              <div className="bg-gradient-to-r from-blue-500/20 to-cyan-500/20 border border-blue-400/30 rounded-lg px-8 py-6">
                <div className="text-4xl font-bold text-white mb-2">
                  ${counter.toLocaleString()}
                </div>
                <div className="text-sm text-gray-400 uppercase tracking-wider">Revenue Recovered</div>
              </div>
            </div>
          </div>

          <div className="bg-gradient-to-br from-slate-800 to-slate-900 border border-blue-400/20 rounded-2xl p-8 shadow-2xl relative z-10">
            <h3 className="text-2xl font-bold text-white mb-2">
              Claim My Free $10K Clinic Fix
            </h3>
            <p className="text-sm text-gray-400 mb-6">
              Normally $297 - free for the first 5 GTA clinics this month
            </p>

            <form
              onSubmit={handleSubmit}
              id="clinic-fix-form"
              data-formspree="true"
              className="space-y-4"
            >
              <input
                type="text"
                name="name"
                placeholder="Full Name"
                required
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="w-full px-4 py-3 bg-slate-700/50 border border-slate-600 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:border-blue-400 transition-colors"
              />
              <input
                type="email"
                name="email"
                placeholder="Work Email"
                required
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                className="w-full px-4 py-3 bg-slate-700/50 border border-slate-600 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:border-blue-400 transition-colors"
              />
              <input
                type="tel"
                name="mobile"
                placeholder="Mobile Number"
                required
                value={formData.mobile}
                onChange={(e) => setFormData({ ...formData, mobile: e.target.value })}
                className="w-full px-4 py-3 bg-slate-700/50 border border-slate-600 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:border-blue-400 transition-colors"
              />
              <input
                type="text"
                name="clinic"
                placeholder="Clinic Name"
                required
                value={formData.clinic}
                onChange={(e) => setFormData({ ...formData, clinic: e.target.value })}
                className="w-full px-4 py-3 bg-slate-700/50 border border-slate-600 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:border-blue-400 transition-colors"
              />
              <div className="flex items-start space-x-3">
                <input
                  type="checkbox"
                  name="consent"
                  required
                  checked={formData.consent}
                  onChange={(e) => setFormData({ ...formData, consent: e.target.checked })}
                  className="mt-1 h-4 w-4 text-blue-500 border-slate-600 rounded focus:ring-blue-400"
                />
                <label className="text-sm text-gray-400">
                  I consent to receive communications from Source X about clinic automation and agree to the privacy policy (CASL compliant)
                </label>
              </div>
              <button
                type="submit"
                className="primary-cta w-full bg-gradient-to-r from-blue-500 to-cyan-500 hover:from-blue-600 hover:to-cyan-600 text-white font-bold py-4 px-6 rounded-lg transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-blue-500/50 disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none"
              >
                Claim My Free $10K Clinic Fix
              </button>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
}
