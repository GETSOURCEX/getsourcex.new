
export default function Problem() {
  return (
    <section className="py-20 bg-black">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-gradient-to-r from-yellow-400 to-yellow-500 mb-6">
            <span className="text-slate-900 font-bold text-4xl">!</span>
          </div>
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
            You Don't Need More Leads.
            <br />
            <span className="bg-gradient-to-r from-blue-400 to-cyan-300 bg-clip-text text-transparent">
              You Need to Stop Losing the Ones You Already Have.
            </span>
          </h2>
        </div>

        <div className="bg-gradient-to-br from-slate-800 to-slate-900 border border-red-500/30 rounded-2xl p-8 md:p-12">
          <p className="text-xl text-gray-300 mb-6 leading-relaxed">
            Most clinics spend thousands generating leads, and then lose{' '}
            <span className="text-red-400 font-bold">30–40%</span> of them to missed calls, slow responses, or no-show chaos.
          </p>
          <p className="text-xl text-gray-300 mb-6 leading-relaxed">
            It's not a people problem, it's a <span className="text-blue-400 font-semibold">system problem</span>.
          </p>
          <p className="text-xl text-gray-300 leading-relaxed">
            The $10K Clinic Fix plugs those leaks using automation that feels human, not robotic.
          </p>

          <div className="mt-12 bg-slate-900/50 border border-yellow-500/30 rounded-xl p-8">
            <div className="text-center">
              <div className="text-5xl font-bold text-yellow-400 mb-4">120</div>
              <div className="text-gray-400 mb-8">Missed Calls Per Month</div>
              <div className="text-xl text-gray-500 mb-4">↓</div>
              <div className="text-5xl font-bold text-red-400 mb-4">$34,560</div>
              <div className="text-gray-400">Annual Revenue Leak</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
