
export default function ProofBar() {
  return (
    <section className="py-16 bg-black border-y border-blue-400/20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-white mb-3">
            Trusted by Clinics Across the GTA
          </h2>
          <p className="text-gray-400 max-w-2xl mx-auto">
            From physiotherapy and Medspas to laser and rehab centers, our systems have helped clinics recover real profit without new ads or staff.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          <div className="bg-gradient-to-br from-slate-700/50 to-slate-800/50 border border-blue-400/20 rounded-xl p-6 text-center transform hover:scale-105 transition-transform duration-300">
            <div className="text-5xl font-bold text-blue-400 mb-4">1,400+</div>
            <div className="text-gray-400 uppercase tracking-wider text-sm">Missed Calls Recovered</div>
          </div>

          <div className="bg-gradient-to-br from-slate-700/50 to-slate-800/50 border border-blue-400/20 rounded-xl p-6 text-center transform hover:scale-105 transition-transform duration-300">
            <div className="text-5xl font-bold text-cyan-400 mb-4">$200K+</div>
            <div className="text-gray-400 uppercase tracking-wider text-sm">in Client ROI</div>
          </div>

          <div className="bg-gradient-to-br from-slate-700/50 to-slate-800/50 border border-blue-400/20 rounded-xl p-6 text-center transform hover:scale-105 transition-transform duration-300">
            <div className="text-5xl font-bold text-blue-400 mb-4">48 Hours</div>
            <div className="text-gray-400 uppercase tracking-wider text-sm">Avg. Setup Time</div>
          </div>
        </div>
      </div>
    </section>
  );
}
