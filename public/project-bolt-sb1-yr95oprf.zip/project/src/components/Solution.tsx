
export default function Solution() {
  const steps = [
    {
      number: '1',
      title: 'Diagnose',
      what: 'We analyze your call data & workflow',
      result: 'Identify your top 3 revenue leaks',
      color: 'from-blue-500 to-blue-600',
    },
    {
      number: '2',
      title: 'Design',
      what: 'You receive your AI Transformation Blueprint',
      result: 'See your 10-day recovery plan',
      color: 'from-cyan-500 to-cyan-600',
    },
    {
      number: '3',
      title: 'Deliver',
      what: 'We install and test your Fix in 48 hours',
      result: 'Recover $10K+ in real revenue',
      color: 'from-blue-600 to-cyan-500',
    },
  ];

  return (
    <section id="solution" className="py-20 bg-black">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">
            The $10K Clinic Fix
          </h2>
          <p className="text-xl text-gray-400 max-w-3xl mx-auto">
            Your AI-Powered Revenue Recovery System
          </p>
          <p className="text-lg text-gray-500 mt-2 max-w-3xl mx-auto">
            We help clinics recover hidden profits with a 3-part process proven to deliver ROI in under 30 days.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 mb-12">
          {steps.map((step, index) => (
            <div
              key={index}
              className="relative bg-gradient-to-br from-slate-800 to-slate-900 border border-blue-400/20 rounded-2xl p-8 hover:border-blue-400/50 transition-all duration-300 transform hover:-translate-y-2 group"
            >
              <div
                className={`absolute top-0 left-0 w-full h-1 bg-gradient-to-r ${step.color} rounded-t-2xl`}
              ></div>
              <div className="flex items-center justify-center mb-6">
                <div
                  className={`flex items-center justify-center w-20 h-20 rounded-full bg-gradient-to-r ${step.color} text-white font-bold text-3xl`}
                >
                  {step.number}
                </div>
              </div>
              <h3 className="text-2xl font-bold text-white mb-4 text-center">{step.title}</h3>
              <div className="space-y-4">
                <div>
                  <div className="text-sm text-gray-500 mb-1 uppercase tracking-wider">What Happens</div>
                  <div className="text-gray-300">{step.what}</div>
                </div>
                <div>
                  <div className="text-sm text-gray-500 mb-1 uppercase tracking-wider">Result</div>
                  <div className="text-blue-400 font-semibold">{step.result}</div>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="text-center">
          <button
            onClick={() => {
              const element = document.querySelector('form');
              if (element) {
                element.scrollIntoView({ behavior: 'smooth', block: 'center' });
              }
            }}
            className="bg-gradient-to-r from-blue-500 to-cyan-500 hover:from-blue-600 hover:to-cyan-600 text-white font-bold py-4 px-8 rounded-lg transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-blue-500/50 text-lg"
          >
            Claim My Free $10K Clinic Fix
          </button>
        </div>
      </div>
    </section>
  );
}
