
export default function Testimonials() {
  const testimonials = [
    {
      name: 'Dr. Sarah Mitchell',
      clinic: 'Toronto Physio & Wellness',
      text: 'We recovered $12,400 in the first month alone. The AI system caught calls we didn\'t even know we were missing. Game changer for our front desk.',
      rating: 5,
    },
    {
      name: 'James Chen',
      clinic: 'Luminous MedSpa',
      text: 'No-shows dropped by 68% and our booking rate went from 40% to 82%. The ROI was visible within two weeks. Incredible investment.',
      rating: 5,
    },
    {
      name: 'Dr. Priya Sharma',
      clinic: 'GTA Laser & Aesthetics',
      text: 'Setup was seamless, and the system works 24/7. Our patients love the instant responses, and we love the revenue recovery. Worth every penny.',
      rating: 5,
    },
  ];

  return (
    <section id="results" className="py-20 bg-black">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">
            Real Results from Real Clinics
          </h2>
          <p className="text-xl text-gray-400">
            See what clinic owners are saying about their recovery
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <div
              key={index}
              className="bg-gradient-to-br from-slate-800 to-slate-900 border border-blue-400/20 rounded-2xl p-8 hover:border-blue-400/50 transition-all duration-300 transform hover:-translate-y-2"
            >
              <div className="flex mb-4 text-2xl">
                {[...Array(testimonial.rating)].map((_, i) => (
                  <span key={i} className="text-yellow-400">★</span>
                ))}
              </div>
              <p className="text-gray-300 mb-6 leading-relaxed italic">
                "{testimonial.text}"
              </p>
              <div className="border-t border-slate-700 pt-4">
                <div className="font-semibold text-white">{testimonial.name}</div>
                <div className="text-sm text-gray-400">{testimonial.clinic}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
