
export default function ValueStack() {
  const items = [
    {
      name: 'The $10K Clinic Fix',
      description: 'Done-for-you system that recovers $10K in lost revenue',
      value: 297,
    },
    {
      name: 'AI Audit + ROI Snapshot',
      description: 'Personalized breakdown of your clinic\'s profit leaks',
      value: 499,
    },
    {
      name: 'Implementation Strategy Call',
      description: 'One-on-one consultation with Source X',
      value: 199,
    },
  ];

  const total = items.reduce((sum, item) => sum + item.value, 0);

  return (
    <section className="py-20 bg-black">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">
            What's Included
          </h2>
          <p className="text-xl text-blue-400">
            Free for the First 5 Clinics
          </p>
        </div>

        <div className="bg-gradient-to-br from-slate-800 to-slate-900 border-2 border-blue-400/30 rounded-2xl overflow-hidden shadow-2xl">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gradient-to-r from-blue-900/50 to-cyan-900/50">
                <tr>
                  <th className="px-6 py-4 text-left text-sm font-semibold text-gray-300">Component</th>
                  <th className="px-6 py-4 text-left text-sm font-semibold text-gray-300">Description</th>
                  <th className="px-6 py-4 text-right text-sm font-semibold text-gray-300">Value</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-700">
                {items.map((item, index) => (
                  <tr key={index} className="hover:bg-slate-700/30 transition-colors">
                    <td className="px-6 py-5">
                      <div className="flex items-center space-x-3">
                        <div className="w-6 h-6 rounded-full bg-green-400 flex items-center justify-center flex-shrink-0">
                          <div className="text-slate-900 font-bold text-sm">✓</div>
                        </div>
                        <span className="text-white font-semibold">{item.name}</span>
                      </div>
                    </td>
                    <td className="px-6 py-5 text-gray-400">{item.description}</td>
                    <td className="px-6 py-5 text-right text-blue-400 font-bold text-lg">
                      ${item.value}
                    </td>
                  </tr>
                ))}
              </tbody>
              <tfoot className="bg-gradient-to-r from-blue-500/20 to-cyan-500/20">
                <tr>
                  <td colSpan={2} className="px-6 py-5 text-left">
                    <span className="text-xl font-bold text-white">Total Value</span>
                  </td>
                  <td className="px-6 py-5 text-right">
                    <span className="text-3xl font-bold text-cyan-400">${total}</span>
                    <div className="text-sm text-gray-400">in Free Value</div>
                  </td>
                </tr>
              </tfoot>
            </table>
          </div>
        </div>

        <div className="text-center mt-12">
          <button
            onClick={() => {
              const element = document.querySelector('form');
              if (element) {
                element.scrollIntoView({ behavior: 'smooth', block: 'center' });
              }
            }}
            className="bg-gradient-to-r from-blue-500 to-cyan-500 hover:from-blue-600 hover:to-cyan-600 text-white font-bold py-4 px-8 rounded-lg transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-blue-500/50 text-lg"
          >
            Claim My Free $10K Clinic Fix
          </button>
        </div>
      </div>
    </section>
  );
}
