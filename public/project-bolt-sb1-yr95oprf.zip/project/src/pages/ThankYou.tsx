import Footer from '../components/Footer';

export default function ThankYou() {
  return (
    <div className="min-h-screen bg-black flex flex-col">
      <div className="flex-grow flex items-center justify-center px-4 sm:px-6 lg:px-8 py-20">
        <div className="max-w-3xl w-full text-center">
          <div className="mb-8">
            <div className="w-24 h-24 rounded-full bg-green-400 flex items-center justify-center mx-auto animate-bounce-slow">
              <span className="text-slate-900 font-bold text-5xl">✓</span>
            </div>
          </div>

          <h1 className="text-4xl md:text-6xl font-bold text-white mb-6">
            You're In - Your $10K Clinic Fix Is Reserved
          </h1>

          <div className="bg-gradient-to-br from-slate-800 to-slate-900 border border-blue-400/20 rounded-2xl p-8 md:p-12 mb-8">
            <h2 className="text-2xl font-bold text-white mb-8">Here's what happens next:</h2>

            <div className="space-y-6 text-left">
              <div className="flex items-start space-x-4">
                <div className="flex-shrink-0 w-12 h-12 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-full flex items-center justify-center text-white font-bold text-xl">
                  1
                </div>
                <div className="flex-grow">
                  <h3 className="text-lg font-semibold text-white mb-2">Check Your Inbox</h3>
                  <p className="text-gray-400">
                    You'll receive your free Clinic Revenue Leak Report and Calculator within the next few minutes.
                  </p>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <div className="flex-shrink-0 w-12 h-12 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-full flex items-center justify-center text-white font-bold text-xl">
                  2
                </div>
                <div className="flex-grow">
                  <h3 className="text-lg font-semibold text-white mb-2">Book Your ROI Snapshot Call</h3>
                  <p className="text-gray-400 mb-4">
                    Schedule your 15-minute ROI Snapshot Call below to walk through your numbers and recovery plan.
                  </p>
                  <a
                    href="https://zeeg.me/vatsalsourcex/15-minute-dollar10k-clinic-fix-roi-snapshot-call"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-block bg-gradient-to-r from-blue-500 to-cyan-500 hover:from-blue-600 hover:to-cyan-600 text-white font-bold py-4 px-8 rounded-lg transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-blue-500/50"
                  >
                    Book My 15-Minute ROI Snapshot Call
                  </a>
                </div>
              </div>
            </div>
          </div>

          <p className="text-gray-400 text-sm">
            Only 5 clinics accepted this month. Secure your audit while spots last.
          </p>
        </div>
      </div>

      <Footer />
    </div>
  );
}
